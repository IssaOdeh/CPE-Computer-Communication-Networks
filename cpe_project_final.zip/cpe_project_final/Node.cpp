/*
*		CPE400
*		Dynamic Routing Mechanism Design in Faulty Network
*		7 December 2020
*		Node.cpp
*/

// The team will simulate a mesh network where nodes and links may fail.
// Nodes and links may fail intermittently, as an input to the simulation, each node and link will have a certain probability to fail.
// When such failure occurs, the network must adapt and re-route to avoid the faulty link/node.
#include "Node.h"
#include <time.h>

#define NUMBER_OF_NODES 10

using namespace std;

//function returns the pointer to a node, given its name
Node * pointer_to_node(char node, map<char, Node*> map_node)
{
	map<char, Node*>::iterator find_iterator = map_node.find(node);
	return (find_iterator->second);
}

//function adds an edge between two nodes, by adding pointers to each other in their connection's lists
void add_new_edge(char first_node, char second_node, map<char, Node*> map_node)
{
	Node * first_node_pointer = pointer_to_node(first_node, map_node);
	Node * second_node_pointer = pointer_to_node(second_node, map_node);

	first_node_pointer->add_new_connection(second_node, second_node_pointer);
	second_node_pointer->add_new_connection(first_node, first_node_pointer);
}

//function removes an edge between two nodes
void remove_edge(char first_node, char second_node, map<char, Node*> map_node)
{
	pointer_to_node(first_node, map_node)->delete_connection(second_node);
	pointer_to_node(second_node, map_node)->delete_connection(first_node);
}

//this function determines whether two nodes are connected
bool node_connection_check(char first_node, char second_node, map<char, Node*> map_node)
{
	return pointer_to_node(first_node, map_node)->is_connected(second_node);
}

struct two_nodes
{
	char node_one;
	char node_two;
};


//this function randomly selects two nodes between A to J
two_nodes select_two_nodes(char nodes_A_J[])
{
	two_nodes selected_nodes;
	selected_nodes.node_one = nodes_A_J[rand() % NUMBER_OF_NODES];
	selected_nodes.node_two = nodes_A_J[rand() % NUMBER_OF_NODES];
	while(selected_nodes.node_one == selected_nodes.node_two)
	{
		selected_nodes.node_one = nodes_A_J[rand() % NUMBER_OF_NODES];
		selected_nodes.node_two = nodes_A_J[rand() % NUMBER_OF_NODES];
	}
	return selected_nodes;
}

//function simulates a thread, and randomly creates and adds edges
void links_for_threads(map<char, Node*> map_node, char nodes_A_J[])
{

	for(int i=0; i<(rand() % 10); i++)
	{
		two_nodes generated_nodes = select_two_nodes(nodes_A_J);
		while(!pointer_to_node(generated_nodes.node_one, map_node)->is_connected(generated_nodes.node_two))
		{
			generated_nodes = select_two_nodes(nodes_A_J);
		}
		cout << "-->Randomly destroyed edge between: (" << generated_nodes.node_one << ", " << generated_nodes.node_two << ")" << endl;
		remove_edge(generated_nodes.node_one, generated_nodes.node_two, map_node);
	}

	//randomly create edges
	for(int i=0; i<(rand() % 10); i++)
	{
		two_nodes generated_nodes = select_two_nodes(nodes_A_J);
		cout << "-->Randomly created edge between: (" << generated_nodes.node_one << ", " << generated_nodes.node_two << ")" << endl;
		add_new_edge(generated_nodes.node_one, generated_nodes.node_two, map_node);
	}
}

//function definition is below in main
void send_RREQ(map<char, Node*> map_node, char src, int request_ID, char destination_node, char nodes_A_J[]);


int main()
{
	char nodes_A_J[NUMBER_OF_NODES] = {'A','B','C','D','E','F','G','H','I','J'};

	// Instantiate nodes A - J
	map<char, Node*>	nothing;
	map<char, Node*>	map_node;
	Node				A('A', nothing);
	Node				B('B', nothing);
	Node				C('C', nothing);
	Node				D('D', nothing);
	Node				E('E', nothing);
	Node				F('F', nothing);
	Node				G('G', nothing);
	Node				H('H', nothing);
	Node				I('I', nothing);
	Node				J('J', nothing);

	//define map
	map_node.insert(pair<char, Node*>('A', A.return_memory_location()));
	map_node.insert(pair<char, Node*>('B', B.return_memory_location()));
	map_node.insert(pair<char, Node*>('C', C.return_memory_location()));
	map_node.insert(pair<char, Node*>('D', D.return_memory_location()));
	map_node.insert(pair<char, Node*>('E', E.return_memory_location()));
	map_node.insert(pair<char, Node*>('F', F.return_memory_location()));
	map_node.insert(pair<char, Node*>('G', G.return_memory_location()));
	map_node.insert(pair<char, Node*>('H', H.return_memory_location()));
	map_node.insert(pair<char, Node*>('I', I.return_memory_location()));
	map_node.insert(pair<char, Node*>('J', J.return_memory_location()));

	//create the edges of the map
	add_new_edge('A', 'B', map_node);
	add_new_edge('B', 'C', map_node);
	add_new_edge('C', 'D', map_node);
	add_new_edge('D', 'E', map_node);
	add_new_edge('D', 'F', map_node);
	add_new_edge('E', 'F', map_node);
	add_new_edge('E', 'H', map_node);
	add_new_edge('F', 'G', map_node);
	add_new_edge('G', 'H', map_node);
	add_new_edge('G', 'I', map_node);
	add_new_edge('H', 'I', map_node);
	add_new_edge('H', 'J', map_node);


	// run the simulation
	srand(time(NULL));

	//fixed test number
	cout << endl << "**************************************" << endl;
	cout << "Fixed network simulation:" << endl;
	cout << endl << "Route Discovery from A to J" << endl;

	send_RREQ(map_node, 'A', rand(), 'J', nodes_A_J);

	cout << endl << "-->Destroyed edge between B and C." << endl;


	cout << endl << "-->Restore edge between B and C, to get get original network back." << endl;
	add_new_edge('B', 'C', map_node);

	//highly volatile example
	cout << endl << "**************************************" << endl;
	cout << "Highly volatile network simulation test:" << endl;

	for(int i=0; i<5; i++)
	{
		cout << endl << "--------------------------------" << endl;
		cout << endl << "TEST #" << i+1 << endl;
		cout << endl << "--------------------------------" << endl;

	// Randomly pick a connection between 2 nodes
		two_nodes generated_nodes = select_two_nodes(nodes_A_J);
		cout << "\nConnection between nodes " << generated_nodes.node_one << " and " << generated_nodes.node_two << ".\n" << endl;

		send_RREQ(map_node, generated_nodes.node_one, rand(), generated_nodes.node_two, nodes_A_J);

	// Call the simulated connection
		links_for_threads(map_node,nodes_A_J);

		cout << endl;
	}

	//redo fixed network, to see if path between A and J changed
	cout << endl << "**************************************" << endl;
	cout << "Now checking if path between A to J changed after some edges were destroyed/created:" << endl;
	cout << endl << "Route Discovery: A to J" << endl;
	cout<< endl <<"*Note: Every test run will have different outcomes*"<<endl<<endl;


	send_RREQ(map_node, 'A', rand(), 'J', nodes_A_J);

	return 0;
}

//simulates an RREQ message
void send_RREQ(map<char, Node*> map_node, char src, int request_ID, char destination_node, char nodes_A_J[])
{
	time_t start = time(0);
	Node * this_node = pointer_to_node(src, map_node);
	this_node->path_is_received = true;

	vector<char> neighboring_vector;
	while(1)
	{
		bool check = true;
		for(int i = 0; i < this_node->previous_requests.size(); i++)
		{
			if(	this_node->previous_requests[i].original_of_RREQ == src &&
				this_node->previous_requests[i].ID_REQUEST_of_RREQ == request_ID)
			{
				check = false;
			}
		}

		if(check)
		{
			request_check insert_record = {src, request_ID};
			this_node-> previous_requests.push_back(insert_record);

			//if current node is desired node, no need to ask neighbors
			if(this_node->node_name != destination_node)
			{
						//for each of current node (this_node) neighbors, ask RREQ
				        for(map<char, Node*>::const_iterator node_iterator = this_node->node_connections.begin(); node_iterator != this_node->node_connections.end(); node_iterator++)

				{
					Node * neighboring_node = node_iterator->second;
					if(neighboring_node->path_is_received == false)
					{
						//send neighboring_node current path taken from original
						neighboring_node->RREQ_string = (this_node->RREQ_string + (this_node->node_name));
						neighboring_node->path_is_received = true;
						if(neighboring_node->node_name == destination_node)
						{
							//found destination_node here
							cout 	<< "Node " << neighboring_node->node_name << " received a RREQ from Node " << this_node->node_name
									<< ".\n\tBegin RREP: ["
									<< (neighboring_node->RREQ_string + neighboring_node->node_name) << "]" << endl;

							//now, begin back to RREQ original by starting RREP
							neighboring_node->send_RREP(destination_node, src, neighboring_node->RREQ_string, (neighboring_node->RREQ_string).size(), destination_node);
						}
						else
						{
							//did not find, so neighboring_node will now ask its neighbors
							cout	<< "Node " << neighboring_node->node_name << " received a RREQ from Node " << this_node->node_name
									<< ".\n\tDestination Node: " << destination_node << ".\n\tNode Path: " << neighboring_node->RREQ_string << endl;
						}
					}
					//add neighboring_node to queue, to forward RREQ
					neighboring_vector.push_back(node_iterator->first);
				}
			}
			else {}
		}

		// Go to the next node in the queue and update this_node
		if(neighboring_vector.size() > 0)
		{
			this_node = pointer_to_node(neighboring_vector[0], map_node);
			neighboring_vector.erase(neighboring_vector.begin());
		}

    	// The destination_node is not in the network if there is no response after 2 seconds
		if(difftime(time(0), start) > 2.0)
		{
			Node * validate_node = pointer_to_node(src, map_node);
			if(!validate_node->received_response)
			{
			cout << "ERROR: Unable to find a path to the node: " << destination_node << endl;
			}
			break;
		}
	}

	// Reset the node
	Node * node_reset = NULL;

	for(int i=0; i<NUMBER_OF_NODES; i++)
	{
		node_reset = pointer_to_node(nodes_A_J[i], map_node);
		node_reset->path_is_received = false;
		node_reset->RREP_string = "";
		node_reset->RREQ_string = "";
	}
	Node * source_node_reset = pointer_to_node(src, map_node);
	source_node_reset->received_response = false;
	source_node_reset->RREP_string = "";
	source_node_reset->RREQ_string = "";
}
