/*
*		CPE400
*		Dynamic Routing Mechanism Design in Faulty Network
*		7 December 2020
*		Node.h
*/


#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <time.h>

using namespace std;

struct request_check
{
	char original_of_RREQ;
	int ID_REQUEST_of_RREQ;
};

class Node
{
	public:
		Node(char letter_node, map<char, Node*> connections);
		Node& operator=(const Node& other);
		Node* return_memory_location();

		char node_name;
		void connections_assignment(map<char, Node*> connections);
		void add_new_connection(char node_name, Node* location);
		void delete_connection(char node_name);
		bool is_connected(char node_name);
		map<char, Node*> node_connections;
		void send_RREP(char src, char destination, string RREQ_reply, int size, char RREP_SRC);

		vector<request_check> previous_requests;
		string RREQ_string;
		string RREP_string;
		bool path_is_received;
		bool received_response;
};

//assignment operator
Node& Node::operator=(const Node& rhs)
{
	if (this == &rhs) return *this;
	return *this;
}

bool Node::is_connected(char node_name)
{
	if(node_connections.count(node_name) > 0)
		return true;
	else
		return false;
}

Node::Node(char letter_node, map<char, Node*> connections)
{
	node_name = letter_node;
	connections_assignment(connections);
	path_is_received = false;
	received_response = false;
}

void Node::connections_assignment(map<char, Node*> connections)
{
	node_connections = connections;
}

void Node::add_new_connection(char node_name, Node* location)
{
	node_connections.insert(std::pair<char, Node*>(node_name, location));
}

void Node::delete_connection(char node_name)
{
	node_connections.erase(node_name);
}


Node* Node::return_memory_location()
{
	return this;
}



//this simulates an RREQ message; it is implemented recursively, so it will take precedent over other function calls in main()
void Node::send_RREP(char src, char destination, string RREQ_reply, int size, char RREP_SRC)
{

	if(size == 0){
		cout	<< "Node " << node_name << " successfully received path to Node " << RREP_SRC
				<< " with route [" << RREQ_reply << RREP_SRC << "]" << endl;
	}
	else if(size == (RREQ_reply.size()-1)){
		cout 	<< "Node " << node_name << " received RREP from Node " << RREP_SRC
				<< " to Node " << destination << " with route [" << RREQ_reply << RREP_SRC << "]" <<endl;
	}
	else if(size != RREQ_reply.size()){
		cout 	<< "Node " << node_name << " received RREP from Node " << RREQ_reply[size+1]
				<< " to Node " << destination << " with route [" << RREQ_reply << RREP_SRC << "]" << endl;
	}
	else {}

	//send next RREP along path
	received_response = true;
	map<char, Node*>::iterator find_iterator;
	Node * next_node = NULL;

	if((size-1) >= 0)
	{
		if(size != 0)
		{
			find_iterator = node_connections.find(RREQ_reply[size-1]);
		}
		next_node = find_iterator->second;
	}
	if(next_node != NULL)
	{
		next_node->RREP_string = RREQ_reply;
		next_node->send_RREP(next_node->node_name, destination, RREQ_reply, size-1, RREP_SRC);
	}
}
