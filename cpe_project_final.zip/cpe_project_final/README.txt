Dynamic Routing Mechanism Design in Faulty Network
CPE 400
7 December 2020

------------------------------------------------------------------------------------------------------

PROGRAM INFORMATION:

	- Written in C++
	- Contains the following files:
		- Node.h
		- Node.cpp

------------------------------------------------------------------------------------------------------

INSTRUCTIONS TO COMPILE AND EXECUTE:

	Compile the program:

  	   >> g++ Node.cpp -o Node

	      //alternatively, you can just run 'make' such as:
	   >> make

	Execute the program:

	   >> ./Node
	
------------------------------------------------------------------------------------------------------

FUNCTION DESCRIPTIONS:

Node& Node::operator=(const Node& rhs)

	>> Overrides the assignment operator.

bool Node::is_connected(char node_name)

	>> Returns true if node is connected; false otherwise.

void Node::connections_assignment(map<char, Node*> connections)

	>> Assigns the node connections.

void Node::add_single_connection(char node_name, Node* location)

	>> Inserts a single connection between nodes.

void Node::delete_single_connection(char node_name)

	>> Removes a single connection between nodes.

void Node::send_RREP(char src, char destination_node, string RREQ_reply, int size, char RREP_SRC)

	>> Recursively simulates an RREP (route reply) message. Outputs which nodes
	>> received an RREP message.

Node* pointer_to_node(char node, map<char, Node*> map_node)
	
	>> Returns the pointer to a node based on the name that is given via parameter.

void add_new_edge(char first_node, char second_node, map<char, Node*> map_node)

	>> Create an edge between 2 nodes by adding pointers to each node within
	>> the connection list.

void remove_edge(char first_node, char second_node, map<char, Node*> map_node)

	>> Destroys (removes) an edge between two nodes, given via parameter.

bool node_connection_check(char first_node, char second_node, map<char, Node*> map_node)

	>> Returns true if two nodes are connected; returns false otherwise.

two_nodes select_two_nodes(char nodes_A_J[])

	>> Function will randomly select two nodes between A and J and return
	>> the selected nodes.

void links_for_threads(map<char, Node*> map_node, char nodes_A_J[])

	>> Randomly creates and adds edges and simulates a thread.

void send_RREQ(map<char, Node*> map_node, char src, int request_ID, char destination_node, char nodes_A_J[]);

	>> Simulates an RREQ (route request) message. Attempts to find the desired node
	>> and asks neighboring nodes. Adds neighbors to queue. If there is no response
	>> after 2 seconds, the destination_node node is not in the network.



